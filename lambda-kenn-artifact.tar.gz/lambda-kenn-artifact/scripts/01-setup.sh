#!/bin/bash
# ==============================================================================
# 01-setup.sh | Toolchain Bootstrap & Kernel Shield Deactivation
# Target: CloudLab Wisconsin d7525 (Dual AMD EPYC 7302 / NVIDIA PCIe GPUs)
# Audience: AI/ML Artifact Evaluator
# ==============================================================================
set -e

echo "[\lambda_{Ken-n}] Bootstrapping 10-Node d7525 (AMD EPYC) Environment for Zero-Waste AI..."

echo "[1/6] Waiting for background OS updates to release dpkg lock (CloudLab Systems Reality)..."
while sudo fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1; do
    echo "      Waiting for apt-get lock..."
    sleep 5
done
while sudo fuser /var/lib/apt/lists/lock >/dev/null 2>&1; do
    echo "      Waiting for apt lists lock..."
    sleep 5
done

echo "[2/6] Installing Clang 18, libbpf, GMP, and strict Linux BPF tooling (Native XDP Compilation)..."
sudo apt-get update
# FATAL FIX: DEBIAN_FRONTEND=noninteractive prevents remote SSH GUI hangs during automated evaluation.
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y clang-18 libbpf-dev libgmp-dev linux-tools-common linux-tools-$(uname -r) docker.io

echo "[3/6] Configuring OS and dropping Kernel Telemetry Shields (Required for Ring-0 PMCs)..."
sudo swapoff -a || true

# CRITICAL METRIC (Claim C2): Unlock Performance Monitoring Counters (PMCs).
# These parameters must be unlocked to physically validate the 142 CPU cycle eBPF execution claim 
# natively on the physical AMD/Mellanox NIC to prove GPUDirect RDMA lane protection.
sudo sysctl -w kernel.bpf_stats_enabled=1
sudo sysctl -w kernel.perf_event_paranoid=-1

# CRITICAL FIX: Add the dynamic Evaluator account to the docker group 
# to prevent fatal permission errors during the Layer-7 Envoy Wasm proxy injection.
sudo usermod -aG docker "$USER" || true

echo "[4/6] Installing GHC v9.6.3 and Agda (The Univalent Verification Substrate)..."
export BOOTSTRAP_HASKELL_NONINTERACTIVE=1
curl --proto '=https' --tlsv1.2 -sSf https://get-ghcup.haskell.org | sh
source "$HOME/.ghcup/env"
ghcup install ghc 9.6.3
ghcup set ghc 9.6.3
cabal update
cabal install Agda-2.6.4.3 --overwrite-policy=always

echo "[5/6] Wiring Cartesian Cubical Type Theory libraries..."
mkdir -p "$HOME/.agda"
echo "$HOME/.cubical/cubical.agda-lib" > "$HOME/.agda/libraries"
echo "cubical" > "$HOME/.agda/defaults"

echo "[6/6] Exporting Cabal binary paths idempotently..."
# Idempotent path appending to prevent ~/.bashrc pollution on multiple Evaluator runs.
if ! grep -q "$HOME/.cabal/bin" "$HOME/.bashrc"; then
    echo 'export PATH="$HOME/.cabal/bin:$HOME/.ghcup/bin:$PATH"' >> "$HOME/.bashrc"
fi
export PATH="$HOME/.cabal/bin:$HOME/.ghcup/bin:$PATH"

echo "[✔] AI Bootstrap Complete. Hardware telemetry is unlocked and the d7525 bare-metal environment is ready to execute O(|V|) extraction."
